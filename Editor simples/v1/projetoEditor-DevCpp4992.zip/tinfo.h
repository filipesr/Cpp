//tinfo.h

typedef void* tinfo; 
typedef char* string;
